# Build the APK

## Easiest: GitHub Actions
1. Create a new GitHub repository.
2. Upload the contents of this project to the repository.
3. Open **Actions** and run **Build APK** (or push to `main`).
4. When the workflow finishes, open the workflow run and download the **ReduceX-debug-apk** artifact.
5. Inside the artifact is `app-debug.apk`.

## Android Studio
Open the `ReduceX` folder in Android Studio, allow Gradle sync, then use **Build > Build APK(s)**.

The debug APK is unsigned for Play Store release distribution, but it can be installed manually on an Android device after allowing installation from that source.
