
package com.reduzx.app;

import android.app.Activity;
import android.os.Bundle;
import android.os.Build;
import android.provider.MediaStore;
import android.content.*;
import android.graphics.*;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.view.*;
import android.widget.*;
import java.io.*;
import java.text.DecimalFormat;
import java.util.concurrent.*;

public class MainActivity extends Activity {
    static final int PICK = 41;
    final int TEAL = Color.rgb(69,197,179);
    final ExecutorService executor = Executors.newSingleThreadExecutor();

    LinearLayout root, controls;
    ImageView preview;
    ProgressBar spinner;
    TextView info, title;
    Button select, resizeBtn;
    Button b25,b50,b75,b100, low,med,high;
    TextView simpleTab, advancedTab;
    Uri imageUri;
    Bitmap original;
    int sizePercent = 75;
    int quality = 75;

    int dp(float v){ return (int)(v*getResources().getDisplayMetrics().density+0.5f); }

    @Override public void onCreate(Bundle b){
        super.onCreate(b);
        buildHome();
    }

    TextView tv(String s, float sp, int color){
        TextView t = new TextView(this);
        t.setText(s); t.setTextSize(sp); t.setTextColor(color);
        t.setGravity(Gravity.CENTER_VERTICAL);
        return t;
    }

    GradientDrawable bg(int color, float radius){
        GradientDrawable g=new GradientDrawable(); g.setColor(color); g.setCornerRadius(dp(radius)); return g;
    }
    GradientDrawable stroke(int color, int line, float radius){
        GradientDrawable g=new GradientDrawable(); g.setColor(Color.TRANSPARENT);
        g.setStroke(dp(line), color); g.setCornerRadius(dp(radius)); return g;
    }

    void buildHome(){
        root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setBackgroundColor(Color.WHITE);
        setContentView(root);

        LinearLayout bar=new LinearLayout(this); bar.setGravity(Gravity.CENTER_VERTICAL); bar.setPadding(dp(22),0,dp(18),0);
        bar.setBackgroundColor(Color.WHITE);
        TextView back=tv("‹",38,Color.DKGRAY);
        bar.addView(back,new LinearLayout.LayoutParams(dp(35),dp(58)));
        title=tv("↗ ReduceX",22,Color.rgb(35,35,35)); title.setTypeface(null,1);
        bar.addView(title,new LinearLayout.LayoutParams(-2,dp(58)));
        root.addView(bar,new LinearLayout.LayoutParams(-1,dp(58)));

        LinearLayout body=new LinearLayout(this); body.setOrientation(LinearLayout.VERTICAL); body.setGravity(Gravity.CENTER_HORIZONTAL);
        body.setPadding(dp(28),dp(70),dp(28),dp(32));
        Space top=new Space(this); body.addView(top,new LinearLayout.LayoutParams(1,dp(45)));
        TextView art=tv("↥",90,TEAL); art.setGravity(Gravity.CENTER);
        body.addView(art,new LinearLayout.LayoutParams(-1,dp(150)));
        TextView hint=tv("Select an image to resize from your device",18,Color.DKGRAY); hint.setGravity(Gravity.CENTER);
        body.addView(hint,new LinearLayout.LayoutParams(-1,dp(55)));
        Space gap=new Space(this); body.addView(gap,new LinearLayout.LayoutParams(1,0,1));
        select=new Button(this); select.setText("Select Image"); select.setTextSize(18); select.setTextColor(Color.WHITE); select.setAllCaps(false); select.setBackground(bg(TEAL,32));
        LinearLayout.LayoutParams sp=new LinearLayout.LayoutParams(-1,dp(58)); sp.setMargins(dp(92),0,dp(92),dp(35));
        body.addView(select,sp); select.setOnClickListener(v->pickImage());
        root.addView(body,new LinearLayout.LayoutParams(-1,0,1));
    }

    void pickImage(){
        Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT); i.setType("image/*"); i.addCategory(Intent.CATEGORY_OPENABLE);
        startActivityForResult(i,PICK);
    }

    @Override protected void onActivityResult(int r,int c,Intent d){
        super.onActivityResult(r,c,d);
        if(r==PICK && c==RESULT_OK && d!=null){
            imageUri=d.getData();
            try { getContentResolver().takePersistableUriPermission(imageUri,d.getFlags()&Intent.FLAG_GRANT_READ_URI_PERMISSION); } catch(Exception ignored){}
            showEditor();
        }
    }

    void showEditor(){
        root.removeAllViews();
        LinearLayout bar=new LinearLayout(this); bar.setGravity(Gravity.CENTER_VERTICAL); bar.setPadding(dp(22),0,dp(18),0);
        TextView back=tv("‹",38,Color.DKGRAY); bar.addView(back,new LinearLayout.LayoutParams(dp(35),dp(58)));
        title=tv("↗ ReduceX",22,Color.rgb(35,35,35)); title.setTypeface(null,1); bar.addView(title,new LinearLayout.LayoutParams(-2,dp(58)));
        back.setOnClickListener(v->buildHome());
        root.addView(bar,new LinearLayout.LayoutParams(-1,dp(58)));

        FrameLayout frame=new FrameLayout(this);
        frame.setBackground(new DiagonalDrawable());
        preview=new ImageView(this); preview.setScaleType(ImageView.ScaleType.FIT_CENTER);
        frame.addView(preview,new FrameLayout.LayoutParams(-1,-1));
        spinner=new ProgressBar(this); spinner.setIndeterminate(true);
        FrameLayout.LayoutParams prog=new FrameLayout.LayoutParams(dp(58),dp(58),Gravity.CENTER);
        frame.addView(spinner,prog);
        info=tv("Loading…",16,Color.WHITE); info.setGravity(Gravity.CENTER);
        info.setBackground(bg(Color.argb(170,0,0,0),2));
        FrameLayout.LayoutParams ip=new FrameLayout.LayoutParams(-2,dp(46),Gravity.BOTTOM|Gravity.CENTER_HORIZONTAL); ip.setMargins(0,0,0,dp(18));
        frame.addView(info,ip);
        root.addView(frame,new LinearLayout.LayoutParams(-1,0,1));

        LinearLayout tabs=new LinearLayout(this); tabs.setGravity(Gravity.CENTER); tabs.setPadding(0,dp(5),0,0);
        simpleTab=tv("Simple",28,TEAL); simpleTab.setGravity(Gravity.CENTER);
        advancedTab=tv("Advanced",28,Color.DKGRAY); advancedTab.setGravity(Gravity.CENTER);
        tabs.addView(simpleTab,new LinearLayout.LayoutParams(0,dp(75),1)); tabs.addView(advancedTab,new LinearLayout.LayoutParams(0,dp(75),1));
        root.addView(tabs,new LinearLayout.LayoutParams(-1,dp(80)));
        simpleTab.setOnClickListener(v->showSimple());
        advancedTab.setOnClickListener(v->showAdvanced());

        controls=new LinearLayout(this); controls.setOrientation(LinearLayout.VERTICAL); controls.setPadding(dp(40),0,dp(40),dp(22));
        root.addView(controls,new LinearLayout.LayoutParams(-1,dp(315)));
        showSimple();
        loadOriginal();
    }

    void showSimple(){
        simpleTab.setTextColor(TEAL); advancedTab.setTextColor(Color.DKGRAY);
        controls.removeAllViews();
        addLabel("Size");
        LinearLayout sizes=row();
        b25=choice("25%"); b50=choice("50%"); b75=choice("75%"); b100=choice("100%");
        sizes.addView(b25,weight()); sizes.addView(b50,weight()); sizes.addView(b75,weight()); sizes.addView(b100,weight());
        controls.addView(sizes);
        setSizeButtons();
        b25.setOnClickListener(v->{sizePercent=25;setSizeButtons();schedulePreview();});
        b50.setOnClickListener(v->{sizePercent=50;setSizeButtons();schedulePreview();});
        b75.setOnClickListener(v->{sizePercent=75;setSizeButtons();schedulePreview();});
        b100.setOnClickListener(v->{sizePercent=100;setSizeButtons();schedulePreview();});
        addLabel("Quality");
        LinearLayout qs=row();
        low=choice("Low"); med=choice("Medium"); high=choice("High");
        qs.addView(low,weight());qs.addView(med,weight());qs.addView(high,weight());controls.addView(qs);
        setQualityButtons();
        low.setOnClickListener(v->{quality=45;setQualityButtons();schedulePreview();});
        med.setOnClickListener(v->{quality=75;setQualityButtons();schedulePreview();});
        high.setOnClickListener(v->{quality=92;setQualityButtons();schedulePreview();});
        resizeBtn=new Button(this); resizeBtn.setText("Resize"); resizeBtn.setTextSize(18); resizeBtn.setTextColor(Color.WHITE); resizeBtn.setAllCaps(false); resizeBtn.setBackground(bg(TEAL,32));
        LinearLayout.LayoutParams rp=new LinearLayout.LayoutParams(-1,dp(58));rp.setMargins(dp(80),dp(28),dp(80),0);controls.addView(resizeBtn,rp);
        resizeBtn.setOnClickListener(v->saveImage());
    }

    void showAdvanced(){
        simpleTab.setTextColor(Color.DKGRAY); advancedTab.setTextColor(TEAL);
        controls.removeAllViews();
        addLabel("Target file size (KB)");
        EditText kb=new EditText(this); kb.setHint("Example: 100"); kb.setInputType(2); kb.setText("100"); controls.addView(kb,new LinearLayout.LayoutParams(-1,dp(52)));
        addLabel("Output format");
        Spinner sp=new Spinner(this); String[] arr={"JPEG","WEBP","PNG"}; sp.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,arr)); controls.addView(sp,new LinearLayout.LayoutParams(-1,dp(52)));
        resizeBtn=new Button(this);resizeBtn.setText("Compress to Target");resizeBtn.setTextSize(18);resizeBtn.setTextColor(Color.WHITE);resizeBtn.setAllCaps(false);resizeBtn.setBackground(bg(TEAL,32));
        LinearLayout.LayoutParams rp=new LinearLayout.LayoutParams(-1,dp(58));rp.setMargins(dp(80),dp(22),dp(80),0);controls.addView(resizeBtn,rp);
        resizeBtn.setOnClickListener(v->{
            int target=100; try{target=Integer.parseInt(kb.getText().toString());}catch(Exception ignored){}
            final int t=Math.max(5,target);
            compressTarget(t,sp.getSelectedItemPosition());
        });
    }

    void addLabel(String s){ TextView l=tv(s,18,Color.DKGRAY); controls.addView(l,new LinearLayout.LayoutParams(-1,dp(48))); }
    LinearLayout row(){ LinearLayout r=new LinearLayout(this); r.setOrientation(LinearLayout.HORIZONTAL); r.setGravity(Gravity.CENTER); return r; }
    LinearLayout.LayoutParams weight(){ LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,dp(52),1);p.setMargins(dp(4),0,dp(4),0);return p; }
    Button choice(String s){Button b=new Button(this);b.setText(s);b.setTextSize(16);b.setTextColor(Color.DKGRAY);b.setAllCaps(false);b.setBackground(stroke(TEAL,1,28));return b;}
    void setButton(Button b,boolean selected){b.setTextColor(selected?Color.WHITE:Color.DKGRAY);b.setBackground(selected?bg(TEAL,28):stroke(TEAL,1,28));}
    void setSizeButtons(){setButton(b25,sizePercent==25);setButton(b50,sizePercent==50);setButton(b75,sizePercent==75);setButton(b100,sizePercent==100);}
    void setQualityButtons(){setButton(low,quality==45);setButton(med,quality==75);setButton(high,quality==92);}

    void loadOriginal(){
        spinner.setVisibility(View.VISIBLE);
        executor.execute(()->{
            try{
                Bitmap b=decodeUri(imageUri,1600);
                original=b;
                runOnUiThread(()->{preview.setImageBitmap(b);schedulePreview();});
            }catch(Exception e){runOnUiThread(()->info.setText("Unable to open image"));}
        });
    }

    Bitmap decodeUri(Uri u,int max) throws Exception{
        Bitmap b=BitmapFactory.decodeStream(getContentResolver().openInputStream(u));
        if(b==null)throw new IOException();
        int w=b.getWidth(),h=b.getHeight();
        float scale=Math.min(1f,(float)max/Math.max(w,h));
        if(scale<1f){Bitmap n=Bitmap.createScaledBitmap(b,Math.max(1,(int)(w*scale)),Math.max(1,(int)(h*scale)),true);b.recycle();b=n;}
        return b;
    }

    void schedulePreview(){
        if(original==null)return;
        spinner.setVisibility(View.VISIBLE);
        executor.execute(()->{
            Bitmap p=resize(original,sizePercent);
            ByteArrayOutputStream out=new ByteArrayOutputStream();
            p.compress(Bitmap.CompressFormat.JPEG,quality,out);
            int kb=Math.max(1,out.size()/1024);
            runOnUiThread(()->{
                preview.setImageBitmap(p);
                info.setText(p.getWidth()+" × "+p.getHeight()+" | "+kb+" kB");
                spinner.setVisibility(View.GONE);
            });
        });
    }

    Bitmap resize(Bitmap b,int percent){
        int w=Math.max(1,b.getWidth()*percent/100), h=Math.max(1,b.getHeight()*percent/100);
        return Bitmap.createScaledBitmap(b,w,h,true);
    }

    void compressTarget(int targetKB,int format){
        if(original==null)return;
        spinner.setVisibility(View.VISIBLE);
        executor.execute(()->{
            int lo=5,hi=100,best=5;Bitmap bestBmp=null;
            for(int i=0;i<8;i++){
                int q=(lo+hi)/2;
                Bitmap p=resize(original,100);
                ByteArrayOutputStream o=new ByteArrayOutputStream();
                Bitmap.CompressFormat cf=format==1?Bitmap.CompressFormat.WEBP:format==2?Bitmap.CompressFormat.PNG:Bitmap.CompressFormat.JPEG;
                p.compress(cf,q,o);
                int kb=o.size()/1024;
                if(kb<=targetKB){best=q;bestBmp=p;lo=q+1;}else{hi=q-1;}
            }
            if(bestBmp==null)bestBmp=resize(original,50);
            Bitmap result=bestBmp;
            runOnUiThread(()->{preview.setImageBitmap(result);info.setText(result.getWidth()+" × "+result.getHeight()+" | target ≤ "+targetKB+" kB");spinner.setVisibility(View.GONE);});
        });
    }

    void saveImage(){
        if(original==null)return;
        executor.execute(()->{
            try{
                Bitmap out=resize(original,sizePercent);
                ByteArrayOutputStream bytes=new ByteArrayOutputStream();out.compress(Bitmap.CompressFormat.JPEG,quality,bytes);
                String name="ReduceX_"+System.currentTimeMillis()+".jpg";
                ContentValues v=new ContentValues();v.put(MediaStore.Images.Media.DISPLAY_NAME,name);v.put(MediaStore.Images.Media.MIME_TYPE,"image/jpeg");
                if(Build.VERSION.SDK_INT>=29)v.put(MediaStore.Images.Media.RELATIVE_PATH,"Pictures/ReduceX");
                Uri u=getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI,v);
                if(u==null)throw new IOException();
                OutputStream os=getContentResolver().openOutputStream(u);os.write(bytes.toByteArray());os.close();
                runOnUiThread(()->Toast.makeText(this,"Saved to Pictures/ReduceX",Toast.LENGTH_SHORT).show());
            }catch(Exception e){runOnUiThread(()->Toast.makeText(this,"Save failed",Toast.LENGTH_SHORT).show());}
        });
    }

    @Override protected void onDestroy(){super.onDestroy();executor.shutdownNow();}

    static class DiagonalDrawable extends Drawable {
        Paint p=new Paint(Paint.ANTI_ALIAS_FLAG);
        @Override public void draw(Canvas c){
            p.setShader(new LinearGradient(0,0,getBounds().width(),getBounds().height(),Color.rgb(35,35,35),Color.rgb(25,25,25),Shader.TileMode.CLAMP));
            c.drawRect(getBounds(),p);
            p.setShader(null);p.setColor(Color.argb(25,255,255,255));p.setStrokeWidth(3);
            for(int x=-getBounds().height();x<getBounds().width();x+=18)c.drawLine(x,0,x+getBounds().height(),getBounds().height(),p);
        }
        public void setAlpha(int a){} public void setColorFilter(android.graphics.ColorFilter f){} public int getOpacity(){return PixelFormat.OPAQUE;}
    }
}
