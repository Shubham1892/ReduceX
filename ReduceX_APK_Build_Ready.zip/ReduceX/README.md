# ReduceX

A native Android image resizer/compressor inspired by the visual layout in the supplied screenshots.

Features:
- Similar teal/white UI
- Image picker
- Fast local preview with loading spinner
- 25%, 50%, 75%, 100% resize presets
- Low/Medium/High JPEG quality
- Advanced custom target KB mode
- JPEG/WebP/PNG output options
- Saves to Pictures/ReduceX
- No ads, no analytics, no cloud upload

Build:
1. Open this folder in Android Studio.
2. Let Gradle sync.
3. Run on an Android device/emulator.
4. Build > Build APK(s).

Note: The app is an original implementation inspired by the supplied screenshots. It does not copy the original app's proprietary assets or branding.
